﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour {

	public void LoadLevel (string strName)
	{
		Debug.Log("Level '" + strName + "' requested for load.");
		SceneManager.LoadScene(strName);
	}//End Method LoadLevel

	public void QuitRequest ()
	{
		Debug.Log("Quit Request received");
		Application.Quit();
	}//End Method QuitRequest

}//End Class LevelManager
