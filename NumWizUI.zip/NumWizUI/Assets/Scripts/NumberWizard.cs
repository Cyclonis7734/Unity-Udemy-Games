﻿using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using System.Collections;
using UnityEngine.SceneManagement;

public class NumberWizard : MonoBehaviour {
	int intMax;
	int intMin;
	int intGuess;
	int intMaxGuesses = 10;

	public Text txt;

	// Use this for initialization
	void Start () {
		StartGame();
	}

	//Beginning Code to run
	void StartGame ()
	{
		intMax = 1000;
		intMin = 1;
		NextGuess();
	}

	public void GuessHigher ()
	{
		intMin = intGuess;
		NextGuess();
	}

	public void GuessLower ()
	{
		intMax = intGuess;
		NextGuess();
	}


	void NextGuess ()
	{
		//Check to see if current guess was correct
		//before ending the game as a win.
		if (intMaxGuesses <= 0) {
			SceneManager.LoadScene("Win");
		}
		intGuess = Random.Range(intMin,intMax + 1);
		intMaxGuesses = intMaxGuesses - 1;
		txt.text = intGuess.ToString();


	}

	public void GuessedCorrect ()
	{
		SceneManager.LoadScene("Lose");
	}




}
